import { LightningElement,api } from 'lwc';
import { FlowNavigationNextEvent } from 'lightning/flowSupport';

export default class AddExternalAccount extends LightningElement {
    heading='Please Enter External Account Details'
    @api accountType=''
    @api routingNumber=''
    @api accountNumber=''
    @api confirmAccountNumber=''

    get options() {
        return [
            { label: 'Checking/Money Market', value: 'checking' },
            { label: 'Savings', value: 'savings' },
        ];
    }

    handleAccountType(event){
        this.accountType = event.target.value;
        //console.log(this.accountType);
    }

    handleRoutingNumber(event){
        this.routingNumber = event.target.value;
    }

    handleAccountNumber(event){
        this.accountNumber=event.target.value;
    }

    handleConfirmAccountNumber(event){
        this.confirmAccountNumber=event.target.value;        
    }

    handleConfirmClick(){
        let element = [...this.template.querySelectorAll('.requiredField')]
                        .reduce((valid, field)=>{
                            field.reportValidity()
                            return valid && field.reportValidity()
                        },true)
        
        if(element)
        {
            if(this.confirmAccountNumber!=this.accountNumber)
            {
                alert("Account number & Confirm account number should be same!!!")
            }
            else
            {
                const navigateNextEvent = new FlowNavigationNextEvent();
                this.dispatchEvent(navigateNextEvent);
            }            
        }
    }
}