import { LightningElement,api } from 'lwc';

export default class AccountProgressIndicator extends LightningElement {
    @api currentStep
    @api steps=[]

}