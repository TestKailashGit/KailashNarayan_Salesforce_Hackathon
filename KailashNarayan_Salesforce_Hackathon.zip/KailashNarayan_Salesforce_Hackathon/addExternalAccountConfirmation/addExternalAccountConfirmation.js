import { LightningElement } from 'lwc';
import { FlowNavigationBackEvent } from 'lightning/flowSupport';

export default class AddExternalAccountConfirmation extends LightningElement {
    heading='Please Review Your Account Details'
    routingNumber='123456'
    bankName='FEDERAL RESERVE BANK OF BOSTON'
    accountNumber='123456789'
    accountType='CHECKING'
    agreementDisclosureHeading='Agreement and Election for the Electronic Delivery of all Account Disclosure and Notices'
    agreementDetails='Please read to the terms and conditions and confirm the Agreement and Election for the Electronic Delivery of all Account Disclosure and Notices'
    confirmAgreement='I have read and understood the Agreement and Election for the Electronic Delivery of all Account Disclosure and Notices'
    acknowledgmentText='I acknowledge the Agreement and Election for the Electronic Delivery of all Account Disclosure and Notices'
    addAccount=true
    editAccount=false
    isChecked

    handleConfirmAgreement(event){
        //this.confirmAgreement=event.target.checked
        this.isChecked=event.target.checked;
        if(this.isChecked){
            this.addAccount=false
            this.editAccount=true
        }
        else
        {
            this.editAccount=false
            this.addAccount=true
        }
    }

    handleEditAccountClick(){
        const navigateBackEvent = new FlowNavigationBackEvent();
        this.dispatchEvent(navigateBackEvent);
    }
}